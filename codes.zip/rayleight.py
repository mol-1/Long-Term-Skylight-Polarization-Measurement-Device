#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 22:02:26 2022

@author: leo
"""

# -- coding: utf-8 --
"""
Created on Wed Sep 29 10:33:08 2021

@author: U607402
"""
import numpy as np
from numpy import arctan2, sqrt
#import numexpr as ne
import matplotlib.pyplot as plt
def average_angle(angle1,angle2):
    x=np.cos(angle1)+np.cos(angle2)
    y=np.sin(angle1)+np.sin(angle2)
    return np.arctan2(y,x)
def myprint(**kwargs):#namestr #https://stackoverflow.com/questions/592746/how-can-you-print-a-variable-name-in-python
    #print(kwargs.items())
    for k,v in kwargs.items():
        print("%s = %s" % (k, repr(v)))
#def myprint(a):
#    print(f'{a=}')
    #namestr(a=a)

#7312 IEEE SENSORS JOURNAL, VOL. 15, NO. 12, DECEMBER 2015


#def cart2sph(x,y,z, ceval=ne.evaluate): # d'après https://stackoverflow.com/questions/4116658/faster-numpy-cartesian-to-spherical-coordinate-conversion
#    """ x, y, z :  ndarray coordinates
#        ceval: backend to use: 
#              - eval :  pure Numpy
#              - numexpr.evaluate:  Numexpr """
#    azimuth = eval('arctan2(y,x)') #ceval
#    xy2 = eval('x**2 + y**2')
#    elevation = eval('arctan2(z, sqrt(xy2))')
#    r = eval('sqrt(xy2 + z**2)')
#    return azimuth, elevation, r
#
#def sph2cart(azimuth,elevation,r): #d'après https://stackoverflow.com/questions/30084174/efficient-matlab-cart2sph-and-sph2cart-functions-in-python
#    #cos-> sin pour l'elevation ; anciennement : x = r * np.cos(elevation) * np.cos(azimuth)
#    x = r * np.sin(elevation) * np.cos(azimuth)
#    y = r * np.sin(elevation) * np.sin(azimuth)
#    z = r * np.cos(elevation)
#    return x, y, z
def cart2sph(x,y,z):
    azimuth = np.arctan2(y,x)
    elevation = np.arctan2(z,np.sqrt(x**2 + y**2))
    r = np.sqrt(x**2 + y**2 + z**2)
    return azimuth, elevation, r

def sph2cart(azimuth,elevation,r):
    x = r * np.cos(elevation) * np.cos(azimuth)
    y = r * np.cos(elevation) * np.sin(azimuth)
    z = r * np.sin(elevation)
    return x, y, z
def cart2sph2(x,y,z):
    """
    Entree : trois tableaux numpy avec les n coordonnées selon l'axe x, y et z de n vecteurs
    Sortie : deux tableaux numpy avec les n coordonnées en azimut et elevation, en radians, avec la convention elevation  à pi/2 si vecteur selon le plan x-y, et nulle selon z.
    """
    azimuth = np.arctan2(y,x)
    elevation = np.pi/2-np.arctan2(z,np.sqrt(x**2 + y**2))
    return azimuth, elevation


def sph2cart2(azimuth,elevation):
    """
    Entree : deux tableaux numpy avec les n coordonnées en azimut et elevation, en radians, avec la convention elevation  à pi/2 si vecteur selon le plan x-y, et nulle selon z.
    Sortie : trois tableaux numpy avec les n coordonnées selon l'axe x, y et z de n vecteurs
    """
    x = np.cos(np.pi/2-elevation) * np.cos(azimuth)
    y = np.cos(np.pi/2-elevation) * np.sin(azimuth)
    z = np.sin(np.pi/2-elevation)
    return x, y, z
#(XSensor,YSensor)=(259,194)#259.2,194.4 #Taille du capteurs en pixels*pixels, on prend un pixel sur 10
#(XCoeff,YCoeff)=(3673.6/XSensor,2738.4/YSensor)#(3673.6/XSensor,2738.4/YSensor) 
##Taille des pixels
##2592*1944 pixels pour ov5647
##3673.6um*2738.4
def rebin(arr, new_shape): #https://scipython.com/blog/binning-a-2d-array-in-numpy/
        shape = (new_shape[0], arr.shape[0] // new_shape[0],
                 new_shape[1], arr.shape[1] // new_shape[1])
        return arr.reshape(shape).mean(-1).mean(1)
def simul_rayleight_subplot(Psi_sun = -85,Theta_sun = 80,ax_aop=None,ax_dop=None,fig=None,theta=None,alpha=None,rot_mat=None):#orientation_pixels_ENU=None):
    if ax_aop is None:
        ax_aop=plt.gca()
    
    (XSensor,YSensor)=(2448,2048)#259.2,194.4 #Taille du capteurs en pixels*pixels, on prend un pixel sur 10
    (x_0,y_0)=(1329.8,952.6)#Centre caméra
    (XCoeff,YCoeff)=(3.45,3.45)#(3673.6/XSensor,2738.4/YSensor)#(3673.6/XSensor,2738.4/YSensor) 
    #Taille des pixels
    #2592*1944 pixels pour ov5647
    #3673.6um*2738.4
    
    
    
    
    
    
    if rot_mat is None:rot_mat=np.identity(3)
    if (alpha is None) or (theta is None):
        
        f=1898 #1200 anc., en um, focale de l'objectif
    
        x = np.arange(0,XSensor,1)
        y = np.arange(0, YSensor, 1)
        xx, yy = np.meshgrid(x, y, sparse=True)
    
        #theta=np.arctan(np.hypot(((xx-XSensor/2)*XCoeff),((yy-YSensor/2)*YCoeff))/f)
        theta=(np.hypot(((xx-XSensor/2)*XCoeff),((yy-YSensor/2)*YCoeff))/f)
        alpha=np.arctan2((yy-YSensor/2)*YCoeff,(xx-XSensor/2)*XCoeff) #les répartitions angulaires correspondantes aux pixels du capteur 2d. Theta = elevation, alpha=azimut
#    else :
#        theta=orientation_pixels_ENU[:,:,1]
#        alpha=orientation_pixels_ENU[:,:,0]
    
    
    
    
    R=1
    # Sun azimut (deg)
    #Psi_sun = -85;    
    # Sun elevation (deg) (null elevation = 90deg) ->0deg mnt : soleil au zenith pour 0°
    #Theta_sun = 80;
    
    
    #Sun azimut (rad)
    Psi_sun = Psi_sun*np.pi/180;
    #Sun elevation (rad)
    Theta_sun = Theta_sun*np.pi/180;
    
    
    #Measurement vector OM
    #Psi : azimuth, Theta : elevation
    
    #Calcul Rayleigh
    #[Xs,Ys,Zs] 
    
    
    #OS = [Xs;Ys;Zs];
    #[Theta,Psi]=np.meshgrid(Theta_range,Psi_range);
    [Theta,Psi]=[theta,alpha] #on recolle avec le simulateur de Stephane

    
    #xsi=np.arctan2((np.cos(Theta)*np.cos(Theta_sun)-np.sin(Theta)*np.cos(Psi-Psi_sun)*np.sin(Theta_sun)),(np.sin(Psi-Psi_sun)*np.sin(Theta_sun)))
    #xsi=np.arctan2((np.cos(Theta)*np.sin(Theta_sun)*np.cos(Psi_sun-Psi)-np.sin(Theta)*np.cos(Theta_sun)),(np.sin(Theta)*np.sin(Psi_sun-Psi)*np.sin(Theta_sun)))#xsi plus recent
    
    xsi=np.arctan2(np.cos(Theta_sun)*np.sin(Theta)-np.sin(Theta_sun)*np.cos(Theta)*np.cos(Psi-Psi_sun),-np.sin(Psi-Psi_sun)*np.sin(Theta_sun))
    #model_pixel_sensors-14-14916
    Xsi=((xsi+Psi)%np.pi-np.pi/2)*180/np.pi
    
    Xsi[theta>np.pi/2]=0 #on enleve ce qui dépasse du champ de vue
    
    
    Xsi=Xsi*np.pi/180
    ####
    #Xsi=np.arange(0,1.01,0.01)*np.pi 
    #####
    Xsi_0=np.cos(Xsi)**2
    Xsi_45=np.cos(Xsi-np.pi/4)**2
    Xsi_90=np.cos(Xsi-np.pi/2)**2
    Xsi_135=np.cos(Xsi-3*np.pi/4)**2
    
    Q=Xsi_0-Xsi_90 # I0-I90
    U=Xsi_45-Xsi_135 # I45-I135
#    ksi=(0.5*np.arctan2(U,Q)*180/np.pi)
#    offset_cadrant=U*0
#    offset_cadrant[(U>0)&(Q<0)]=45
#    offset_cadrant[(U<0)&(Q>0)]=135
#    offset_cadrant[(U<0)&(Q<0)]=90
    
    

    
    #ksi_mean=rebin(ksi,(ksi.shape[0]//4,ksi.shape[1]//4))
    
    
    couleur=0
    Q_dofp=Xsi_0[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]-Xsi_90[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4] # I0-I90
    U_dofp=Xsi_45[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]-Xsi_135[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4] # I45-I135
    ksi_dofp=(-(0.5*np.arctan2(U_dofp,Q_dofp))*180/np.pi-r.as_euler('ZXY')[0]/d+90)%180-90
    
    
    
    I_dofp=ksi_dofp #temporaire, pour afficher un truc
    
    
    
    #I_dofp=0.5*(Xsi_0[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]+Xsi_90[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4]+Xsi_45[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]+Xsi_135[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4]) # (I0 + I90 + I45 + I135)/2
    
    #Calcul du DOP :
#    DOP_dofp=#np.hypot(Q_dofp,U_dofp)/I_dofp
    
    
    
    ##############################################################
#    R=1
#    OS= sph2cart((Psi_sun),(Theta_sun),R);
    #OS= sph2cart((Psi_sun),(np.pi/2-Theta_sun),R);
#OS= sph2cart((Psi_sun),(np.pi/2-Theta_sun),R);
#OS = [Xs;Ys;Zs];
#[Theta,Psi]=np.meshgrid(Theta_range,Psi_range);
#[Theta,Psi]=[theta,alpha] #on recolle avec le simulateur de Stephane
#[OMx,OMy,OMz]=sph2cart(Psi,Theta,R);


#Rayleigh = sky_fun_full_3D(OS,OMx,OMy,OMz,ones(size(OMx)));


####
####                      Debut fonction
####


######function [sky] = sky_fun_full_3D(OS,OMx,OMy,OMz,Sky_lum)

#OM : nxm meshgrid matrix 

    
    alpha_0=alpha[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]
    alpha_90=alpha[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4]
    alpha_45=alpha[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]
    alpha_135=alpha[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4]
    alpha_mini=average_angle(average_angle(alpha_0,alpha_90),average_angle(alpha_45,alpha_135))    
    theta_0=theta[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]
    theta_90=theta[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4]
    theta_45=theta[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]
    theta_135=theta[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4]
    theta_mini=average_angle(average_angle(theta_0,theta_90),average_angle(theta_45,theta_135))
    
    Psi=alpha_mini#rebin(alpha,(alpha.shape[0]//4,alpha.shape[1]//4))
    Theta=theta_mini#rebin(theta,(theta.shape[0]//4,theta.shape[1]//4))    
    ksi_dofp[theta_mini>np.pi/2]=0

    [OMx,OMy,OMz]=sph2cart(Psi,np.pi/2-Theta,R);
    [m,n]=np.shape(OMx);

#Elevation and azimut angle of the measurement vector OM
    #print(OS)
#    print("Psi_sun : "+str(Psi_sun)+" Theta_sun : "+str(Theta_sun))
    OS= (sph2cart((Psi_sun),(np.pi/2-Theta_sun),R))#OS= (sph2cart((Psi_sun),(np.pi/2-Theta_sun),R))
#    print(OS)
    #OS = OS/np.linalg.norm(OS);
    #OS=np.matmul(rot_mat,np.array(OS))#rot_mat*np.array(OS).t
    #print(OS)
    #[az_s,el_s,r] = cart2sph(OS[0],OS[1],OS[2]);
    #print(az_s)
#Elevation angle defined with respect to vector Oz
#el_s = pi/2 - el_s;

#    AOP = np.ones([m,n]);
#    AOP_g = np.ones([m,n]);
#    Ipol = np.ones([m,n]); #degre de polarisation
#    I = np.ones([m,n]);
#    Q = np.ones([m,n]);
#    U = np.ones([m,n]);
    #OM=np.ones([m,n]);
    
    OM=np.rollaxis(np.array([OMx,OMy,OMz]).transpose(),1)
    #import time
    #then=time.time()
    gammab=np.arccos(np.dot(OM,OS))
    DOP=np.square(np.sin(gammab)) / (1+np.square(np.cos(gammab)));
    DOP[Theta>np.pi/2]=0
#    print(DOP.shape)
    #DOP=Ipb
    #print(time.time()-then)
    
#    for i in trange(m):
#        for j in range(n): #INVERSé n <-> m ?????
#            if Theta[i,j]>np.pi/2:
#                Ipol[i,j] =0
#            else:
#                
#                OM_l = [OMx[i,j],OMy[i,j],OMz[i,j]]; 
#                OM_l = OM_l / np.linalg.norm(OM_l);
#            
#                #Elevation and azimut angle of the measurement vector OM
#                ##[az,el,r] = cart2sph(OM_l[0],OM_l[1],OM_l[2]);
#                #Elevation angle defined with respect to vector Oz
#                #el = pi/2 - el;
#            
#                #Cross product in global frame
#                #E=np.cross(OS,OM_l);
#             
#                #El : Vector E defined in the local frame related to OM
#                #PITCH = [cos(el), 0, -sin(el); 0, 1, 0; sin(el), 0, cos(el)];
#            
#                #Elevation angle el defined with respect to horizon
#                #PITCH = [sin(el), 0, -cos(el); 0, 1, 0; cos(el), 0, sin(el)];
#                
#                #Elevation angle el defined with respect to vertical
#                ##PITCH = np.matrix([[np.cos(el), 0, -np.sin(el)], [0, 1, 0], [np.sin(el), 0, np.cos(el)]])
#               
#                ##YAW = np.matrix([[np.cos(az), np.sin(az), 0],  [-np.sin(az), np.cos(az), 0], [0, 0, 1]])
#            
#                #Rotation matrix used to calculate El from E in the global frame
#                ##El = PITCH*YAW*np.matrix(E).T;
#                #El = PITCH*YAW*E;
#                
#                
#                #Definition of the angle of polarisation in the local frame
#    #            angle = np.arctan(El[1]/El[0]);
#    #            #AOP dans rep?re global
#    #            angle_g = np.arctan(-E[0]/E[1]);
#    #            #angle = atan2(El(2),El(1));
#    #            AOP[i,j] = angle;
#    #            AOP_g[i,j] = angle_g;
#                
#                #Definition of the degree of polarisation from the angle gamme between
#                #the solar vector OS and OM
#                #myprint(OS=OS)
#                #myprint(OM_l=OM_l)
#                
#                cos_gamma = np.dot(OS,OM_l);
#                #myprint(cos_gamma=cos_gamma)
#                #cos_gamma = cos_gamma/(norm(OS)*norm(OM));
#                gamma = np.arccos(cos_gamma);
#                #break
#                #Polarization degree Rayleigh def
#                Ip = np.square(np.sin(gamma)) / (1+np.square(np.cos(gamma)));
#                Ipol[i,j] = Ip;
#                DOP=Ipol
#                #break
#        ##############################################################
#    #DOP[theta>np.pi/2]=0 #on enleve ce qui dépasse du champ de vue
#    
#    print(time.time()-then)
    
    
    
    #ksi=ksi+offset_cadrant
    
    ####
    #plt.figure()
    #plt.plot(Xsi,offset_cadrant*np.pi/180,label='offset_cadrant')
    #plt.plot(Xsi,ksi*np.pi/180,label='ksi')
    #plt.plot(Xsi,ksi*np.pi/180+offset_cadrant*np.pi/180,label='ksi+offset')
    #plt.plot(Xsi,Xsi,label='Xsi')
    #plt.legend()
    ####
    #
#    plt.figure()
#    plt.imshow(U,cmap='hsv')
#    plt.title("U")
#    plt.colorbar()
#    plt.figure()
#    plt.imshow(U_dofp,cmap='hsv')
#    plt.title("U_dofp")
#    plt.colorbar()
#    
#    plt.figure()
#    plt.imshow(ksi,cmap='hsv')
#    plt.title("ksi")
#    plt.colorbar()
#    plt.figure()
#    plt.imshow(Xsi,cmap='hsv')
#    plt.title("Xsi")
#    plt.colorbar()
#    
    #plt.figure()
    pcm2=ax_aop.pcolormesh(ksi_dofp,cmap='hsv')
    cbar=fig.colorbar(pcm2,ax=ax_aop)
    cbar.set_ticks([-90,-67.5,-45,-22.5,0,22.5,45,67.5,90])
    cbar.set_label("Angle of Polarization")
    ax_aop.set_title("Rayleigh Model AOP")#- Az : "+"%0.2f" % Psi_sun+" El : "+"%0.2f" % Theta_sun)
    
    pcm2d=ax_dop.pcolormesh(DOP,cmap='jet')
    cbard=fig.colorbar(pcm2d,ax=ax_dop)
    #cbard.set_ticks([-90,-67.5,-45,-22.5,0,22.5,45,67.5,90])
    cbard.set_label("Degree of Polarization")
    ax_dop.set_title("Rayleigh Model DOP ")#- Az : "+"%0.2f" % Psi_sun+" El : "+"%0.2f" % Theta_sun)
    
    #plt.colorbar()
    
#    plt.figure()
#    plt.imshow(ksi_dofp-ksi_mean,cmap='hsv')
#    plt.title("diff ksi reconstruit dofp - ksi mean - Az : "+"%0.2f" % Psi_sun+" El : "+"%0.2f" % Theta_sun)
#    plt.colorbar()
#    
    #DOP=Ipol