
# Le but de ce programme est de trouver dans quelle orientation se trouve le capteur  sony polarisé avec son fisheye en comparant et en mettant en concordance les orientations successives du soleil au cours de la journée et l'emplacement des "taches" correspondant à l'image du soleil.

# Arborescence :

# Entrée du code : 
# - le listing des ephemerides d'une part (azimut - elevation, convention elevation nulle pour un vecteur selon z), nommé Psi_Theta_eph, 
# - ainsi que la liste des centroides du soleil sur le capteur 2d.





# <examples/doc_parameters_basic.py>
import numpy as np
from lmfit import Minimizer, Parameters, report_fit
from scipy.spatial.transform import Rotation as R
import matplotlib.pyplot as plt
def cart2sph2(x,y,z):
    """
    Entree : trois tableaux numpy avec les n coordonnées selon l'axe x, y et z de n vecteurs
    Sortie : deux tableaux numpy avec les n coordonnées en azimut et elevation, en radians, avec la convention elevation  à pi/2 si vecteur selon le plan x-y, et nulle selon z.
    """
    azimuth = np.arctan2(y,x)
    elevation = np.pi/2-np.arctan2(z,np.sqrt(x**2 + y**2))
    return azimuth, elevation


def sph2cart2(azimuth,elevation):
    """
    Entree : deux tableaux numpy avec les n coordonnées en azimut et elevation, en radians, avec la convention elevation  à pi/2 si vecteur selon le plan x-y, et nulle selon z.
    Sortie : trois tableaux numpy avec les n coordonnées selon l'axe x, y et z de n vecteurs
    """
    x = np.cos(np.pi/2-elevation) * np.cos(azimuth)
    y = np.cos(np.pi/2-elevation) * np.sin(azimuth)
    z = np.sin(np.pi/2-elevation)
    return x, y, z


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 10:06:05 2021

@author: leo
"""


import os#, sys
#import numpy as np
#import matplotlib.pyplot as plt
#import matplotlib.animation as animation
from tqdm import trange
import skimage.io
import skimage.filters
#import cv2
#import time
#chaine_hdd='FREECOMHDD/ManipeTExpoFixe'#'023522FB7C52160B'#'CORSAIR'

#chaine_hdd='sf_'#'023522FB7C52160B'#'CORSAIR'
#chaine_dossier='ManipeResultats'#/210622'#220522'
runfile('/media/sf_Echange_MV_Ubuntu/DepouillageINT/centroide_images.py')
#runfile('/media/leo/FREECOMHDD/centroide_images.py')
#runfile('/media/leo/'+chaine_hdd+'/centroide_images.py', wdir='/media/leo/'+chaine_hdd+'/')
runfile('/media/sf_Echange_MV_Ubuntu/DepouillageINT/ephemeride.py')


import tkinter as tk
#from tkinter import filedialog

root = tk.Tk()
root.withdraw()
#path= "/media/leo/FREECOMHDD/ManipeTExpoFixe/ManipeResultats"
path= "/media/sf_ManipeResultats"

#path = "/media/leo/"+chaine_hdd+"/"+chaine_dossier
dirs = os.listdir( path )
dirs_files=[]
for file in dirs:
    if file[-4:]=='.npy':
        dirs_files.append(file)
        
       
def rebin(arr, new_shape): #https://scipython.com/blog/binning-a-2d-array-in-numpy/
    shape = (new_shape[0], arr.shape[0] // new_shape[0],
             new_shape[1], arr.shape[1] // new_shape[1])
    return arr.reshape(shape).mean(-1).mean(1)

        
#file_path = 

#png_raw_name="D:\ManipeResultats\2021-12-14T12-20-12.npy"
#somme_images=np.load(png_raw_name+"0"+"R"+'.npy')*0



#chemins_angles_raw_name=dirs[695-131:695]#filedialog.askopenfilename()#"D:\ManipeResultats
#chemins_angles_raw_name=filedialog.askopenfilename()#"D:\ManipeResultats

i=0
A=np.array([
        [1,2,3,4,5,6,7,8],
        [9,10,11,12,13,14,15,16],
        [17,18,19,20,21,22,23,24],
        [25,26,27,28,29,30,31,32],
        [33,34,35,36,37,38,39,40],
        [41,42,43,44,45,46,47,48],
        [49,50,51,52,53,54,55,56],
        [57,58,59,60,61,62,63,64]])
couleur=3 
# 0 : R     1 : G
# 2 : G     3 : B
indice_pol=0
# 0 :  0°   1 : 45°
# 2 : 135°  3 : 90°

#0° -> Vertical

#plt.figure()

(XSensor,YSensor)=(2448,2048)#259.2,194.4 #Taille du capteurs en pixels*pixels, on prend un pixel sur 10
f=1898 #1200 anc., en um, focale de l'objectif

#(x_0,y_0)=(1329.8,952.6)#Centre caméra
#(x_0,y_0)=(YSensor/2,XSensor/2)#Centre caméra
#(x_0,y_0)=(952.6,1329.8)


(XCoeff,YCoeff)=(1,1)#(3.45,3.45)#(3673.6/XSensor,2738.4/YSensor)#(3673.6/XSensor,2738.4/YSensor) 
x = np.arange(0,XSensor,1)
y = np.arange(0, YSensor, 1)
xx, yy = np.meshgrid(x, y, sparse=True)

        
        
        
eph=ephemerides()        
#theta=rebin(theta,(theta.shape[0]//4,theta.shape[1]//4))

i_image=65
dirs_files.sort()
centroides=[]
Psi_Theta_eph=[]
Psi_Theta_mes=[]

init_somme_image=0

for i_image in trange(len(dirs_files)):
    #if i_image<95:continue
    for chemins_pos in [dirs_files[i_image]]:
        #\2021-12-14T12-20-12.npy"
        #chemins=np.load('/media/leo/'+chaine_hdd+'/'+chaine_dossier+'/'+chemins_pos)
        chemins=np.load(path+'/'+chemins_pos)
    #    liste_angles=np.load(chemins+"liste_angles"+'.npy').size
        nb_superpixels=4#2 autour de celui au centre soit un carré de 5 superpixels de large soit 20 pixels
        i_eme_image=-1
        angles_az=[]
        
    #    plt.figure()
        
        #image=np.load(png_raw_name+str(i)+couleur+'.npy')
        #print(str(liste_angles[0][i])+"image : "+str(i_eme_image)+" "+couleur+" Angle : "+str(config_monture[0]))
#        chemins=np.array(['/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-17/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-20/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-22/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-25/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-28/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-30/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-33/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-35/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-37/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-39/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-42/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-44/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-46/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-49/',
#       '/media/leo/023522FB7C52160B/ManipeResultats/2022-06-24T19-00-51/'],
#      dtype='<U64')
        for chemin in chemins:#chemins_angles_raw_names:
            i_eme_image+=1
            
            #skip all images but not the one with lower exposure
            if i_eme_image!=5:
                continue
            #if i_image>120:continue
            

               
            #png_raw_name='/media/leo/'+chaine_hdd+'/ManipeResultats'+chemin.split('ManipeResultats')[1]
            png_raw_name='/media/sf_ManipeResultats'+chemin.split('ManipeResultats')[1]
            #plt.imshow(image)
    #        plt.title(png_raw_name)
        #    i_eme_image+=1
        #    couleur='R'    
            liste_expo=np.load(png_raw_name+"liste_expo"+'.npy')
            #print("LISTE EXPO :")
            #print(liste_expo)
            liste_angles=np.load(png_raw_name+"liste_angles"+'.npy')
            taille_liste_angles=liste_angles.shape[1]#361
            config_monture=np.load(png_raw_name+"config_monture.npy")
            #print("Config Monture : "+str(config_monture)+" Liste Angles : "+str(liste_angles))
        #
        #    somme_image=np.load(png_raw_name+"0"+"R"+'.npy')*0


            #eph.tracePolarSoleil(chainetps=chemin.split('ManipeResultats/')[1],Ax=ax1[0])
            (Psi_sun,Theta_sun)=eph.getAltAzSoleil(chemin.split('ManipeResultats/')[1])
            #print([Psi_sun,90-Theta_sun])
            
            if 90-Theta_sun<10:continue #Soleil trop bas sur l'horizon

            image=np.load(png_raw_name+str(i_eme_image)+'.npy').astype('int64')
            if init_somme_image==0:
                init_somme_image=1
                somme_image=image.copy()
            else:
                somme_image=somme_image+image
            
            sigma=8
            image_floue= skimage.filters.gaussian(image, sigma=(sigma, sigma), truncate=3.5, multichannel=True)
            centroide_image=centroide(image_floue)
            #print(centroide_image)
            centroides.append(centroide_image)
            
#            theta=(np.hypot(((centroide_image[1]-x_0)*XCoeff),((centroide_image[0]-y_0)*YCoeff))/f)
#            alpha=np.arctan2((centroide_image[0]-y_0)*YCoeff,(centroide_image[1]-x_0)*XCoeff) #les répartitions angulaires correspondantes aux pixels du capteur 2d. Theta = elevation, alpha=azimut
#            Psi_Theta_mes.append([alpha,theta])
            Psi_Theta_eph.append([Psi_sun,Theta_sun])        
            chainetps=chemin.split('ManipeResultats/')[1]
            chaineheure=chainetps.split("T")[1][0:-1].split("-")
            heure_image=Time(chainetps.split("T")[0]+'T'+chaineheure[0]+":"+chaineheure[1]+":"+chaineheure[2])
    #        print(eph.getAltAzSoleil(heure_image))
            
    
            

            
            
            
            continue
            
        

#
#centroides=np.array([[ 927.63278501,  348.95195744],
#       [ 915.75457805,  370.47904148],
#       [ 905.08049563,  392.35834817],
#       [ 895.81631079,  414.36761479],
#       [ 887.50387451,  436.82957903],
#       [ 880.26742462,  459.44199264],
#       [ 874.04664755,  481.84516575],
#       [ 868.97613038,  504.51318122],
#       [ 865.16206743,  527.18431331],
#       [ 862.07013881,  549.73273618],
#       [ 859.74000231,  572.30566002],
#       [ 858.54205321,  594.89220682],
#       [ 858.26910695,  617.45079447],
#       [ 858.87886014,  640.10442256],
#       [ 860.10100039,  661.67285207],
#       [ 862.10472037,  683.9576838 ],
#       [ 864.96489486,  705.90653194],
#       [ 868.35994527,  727.48068492],
#       [ 872.38308738,  748.84907702],
#       [ 877.36617821,  769.9910147 ],
#       [ 882.82143193,  791.03903138],
#       [ 889.06221075,  811.75251676],
#       [ 895.74863622,  832.01505381],
#       [ 903.16677137,  852.25312155],
#       [ 910.94879326,  872.14098153],
#       [ 919.52376439,  891.80602444],
#       [ 928.55651832,  911.14552075],
#       [ 937.97239832,  930.29297173],
#       [ 948.19020111,  949.20846903],
#       [ 958.44302247,  967.42263585],
#       [ 969.51231488,  985.65154536],
#       [ 980.7647845 , 1003.3261805 ],
#       [ 992.54681807, 1020.49545788],
#       [1004.95251742, 1037.85050705],
#       [1017.6751955 , 1054.8814361 ],
#       [1030.92179751, 1071.28475246],
#       [1044.30332316, 1087.63022868],
#       [1058.66389083, 1103.22377682],
#       [1073.11502441, 1118.79593756],
#       [1087.65594823, 1133.68953526],
#       [1102.84369723, 1148.46240145],
#       [1118.30415929, 1162.50378637],
#       [1134.26288196, 1176.29294741],
#       [1150.29791843, 1189.98190266],
#       [1166.85918317, 1202.92518292],
#       [1183.72730139, 1215.72024602],
#       [1200.85173617, 1227.9185034 ],
#       [1218.25727669, 1239.93059187],
#       [1235.86134608, 1250.6249891 ],
#       [1254.23876751, 1261.73925798],
#       [1272.50845163, 1272.51962446],
#       [1291.39321255, 1282.3312171 ],
#       [1330.02511081, 1300.6997311 ],
#       [1369.24551121, 1317.34672081],
#       [1389.13324859, 1324.39635336],
#       [1409.77990004, 1331.33875271],
#       [1430.33866539, 1337.79321703],
#       [1451.40603059, 1343.35398237],
#       [1472.15025096, 1348.26159886],
#       [1493.55506625, 1352.41209394],
#       [1514.77025263, 1356.07772423],
#       [1536.47993125, 1358.91127027],
#       [1558.43626927, 1361.39093183],
#       [1580.2501774 , 1362.7490511 ],
#       [1602.83026863, 1363.35805053],
#       [1625.97880301, 1363.82879851],
#       [1647.28327415, 1362.76847177],
#       [1669.63721239, 1361.1323405 ],
#       [1692.22834084, 1358.5273647 ],
#       [1714.69146744, 1354.74207741],
#       [1737.02427133, 1350.33979424],
#       [1759.54537639, 1344.80404696],
#       [1781.75511688, 1338.53524501],
#       [1803.78062767, 1331.16185694],
#       [1825.87497418, 1322.42948474],
#       [1847.72314577, 1312.8561269 ],
#       [1869.30655918, 1302.0179829 ]])
#
#Psi_Theta_eph=np.array([[1.18236691, 1.38628123],
#       [1.20990512, 1.35670388],
#       [1.23727149, 1.32681839],
#       [1.2645103 , 1.29664877],
#       [1.29171294, 1.26616754],
#       [1.31883724, 1.23549917],
#       [1.34593401, 1.20466742],
#       [1.37314725, 1.17359177],
#       [1.40048866, 1.14234589],
#       [1.42801899, 1.11095224],
#       [1.45580343, 1.07943354],
#       [1.48395952, 1.0477602 ],
#       [1.51247009, 1.01606152],
#       [1.54141636, 0.98436261],
#       [1.57098646, 0.95258358],
#       [1.60123361, 0.92080486],
#       [1.63232247, 0.88900306],
#       [1.66422085, 0.85736869],
#       [1.69728229, 0.82572541],
#       [1.73144421, 0.79432219],
#       [1.76705276, 0.76304421],
#       [1.80425394, 0.73199218],
#       [1.8432772 , 0.70122077],
#       [1.88438362, 0.6707925 ],
#       [1.92794501, 0.64072977],
#       [1.97415469, 0.61121636],
#       [2.0234658 , 0.5822994 ],
#       [2.07630899, 0.55409317],
#       [2.13306527, 0.52677676],
#       [2.19444787, 0.50041653],
#       [2.2610395 , 0.47520307],
#       [2.33306447, 0.45147482],
#       [2.41141197, 0.4293584 ],
#       [2.49656868, 0.40914562],
#       [2.58837172, 0.39124489],
#       [2.68725793, 0.3758942 ],
#       [2.7926714 , 0.36346248],
#       [2.90389275, 0.35425249],
#       [3.01891392, 0.34856345],
#       [3.13659577, 0.34653374],
#       [3.25417581, 0.34824802],
#       [3.36965792, 0.35364449],
#       [3.48092582, 0.36253803],
#       [3.58703945, 0.37472585],
#       [3.68650084, 0.38984306],
#       [3.77889538, 0.40753945],
#       [3.86463324, 0.42757503],
#       [3.94352896, 0.44954011],
#       [4.01605827, 0.47314004],
#       [4.083108  , 0.49824471],
#       [4.14499853, 0.52455824],
#       [4.20210968, 0.55179966],
#       [4.30477296, 0.60875908],
#       [4.39493554, 0.66820416],
#       [4.43630121, 0.69865315],
#       [4.47548918, 0.72940083],
#       [4.51283416, 0.76043426],
#       [4.54850978, 0.79164593],
#       [4.5828952 , 0.82314397],
#       [4.61599553, 0.85472833],
#       [4.64802849, 0.8864125 ],
#       [4.67908456, 0.91810843],
#       [4.70944352, 0.94994286],
#       [4.73906517, 0.98172727],
#       [4.76810265, 1.01348693],
#       [4.7966011 , 1.04514294],
#       [4.82478624, 1.0768288 ],
#       [4.85254729, 1.10830977],
#       [4.88014065, 1.13977278],
#       [4.90749361, 1.17103771],
#       [4.93466809, 1.20208288],
#       [4.96185717, 1.23304094],
#       [4.98893365, 1.26368347],
#       [5.01608415, 1.29414188],
#       [5.04331198, 1.32434187],
#       [5.07070918, 1.35430967],
#       [5.09822911, 1.38392156]])
#
#Psi_Theta_mes=np.array([[-2.72789765,  1.34008395],#theta_az,psi_el
#       [-2.70086581,  1.31341437],
#       [-2.67402815,  1.28618478],
#       [-2.6477529 ,  1.25849662],
#       [-2.62120186,  1.23014139],
#       [-2.59468935,  1.20144222],
#       [-2.56839727,  1.17294551],
#       [-2.54208609,  1.14372154],
#       [-2.51607242,  1.11398715],
#       [-2.48973812,  1.08442796],
#       [-2.46294308,  1.05475819],
#       [-2.43613026,  1.0245348 ],
#       [-2.40899964,  0.99400485],
#       [-2.38125469,  0.96302106],
#       [-2.35403008,  0.93342792],
#       [-2.3250722 ,  0.90264453],
#       [-2.2958044 ,  0.87190956],
#       [-2.26578779,  0.84166424],
#       [-2.23479393,  0.81156408],
#       [-2.20319022,  0.78113772],
#       [-2.16989363,  0.75094149],
#       [-2.13562185,  0.72076517],
#       [-2.10001783,  0.69122241],
#       [-2.0622953 ,  0.6614814 ],
#       [-2.02244755,  0.63245147],
#       [-1.98040703,  0.60335969],
#       [-1.93567525,  0.57487416],
#       [-1.88739188,  0.54710378],
#       [-1.83559898,  0.51944598],
#       [-1.78070952,  0.49353731],
#       [-1.72035989,  0.46780547],
#       [-1.65558771,  0.44372348],
#       [-1.58593664,  0.42076133],
#       [-1.50764978,  0.39895839],
#       [-1.42222533,  0.37921476],
#       [-1.33062388,  0.36133007],
#       [-1.23047543,  0.34650824],
#       [-1.12395275,  0.33325209],
#       [-1.0098517 ,  0.3239009 ],
#       [-0.89331418,  0.31807979],
#       [-0.77193869,  0.31572478],
#       [-0.65184896,  0.31669219],
#       [-0.53247027,  0.32130638],
#       [-0.41788392,  0.330112  ],
#       [-0.30911858,  0.34141518],
#       [-0.20704938,  0.35609603],
#       [-0.11303337,  0.37304381],
#       [-0.02658896,  0.39263643],
#       [ 0.05229138,  0.41250073],
#       [ 0.12651366,  0.43562089],
#       [ 0.19276595,  0.46025971],
#       [ 0.25519131,  0.48528534],
#       [ 0.36592064,  0.53861718],
#       [ 0.45974608,  0.59499875],
#       [ 0.50262659,  0.62309559],
#       [ 0.54370656,  0.65278384],
#       [ 0.58167324,  0.68264805],
#       [ 0.61878835,  0.71262406],
#       [ 0.65320751,  0.742202  ],
#       [ 0.68728566,  0.77228724],
#       [ 0.71917483,  0.80231138],
#       [ 0.7507632 ,  0.83259772],
#       [ 0.78100024,  0.86351458],
#       [ 0.81057435,  0.89357264],
#       [ 0.84030374,  0.92448778],
#       [ 0.86898479,  0.95679321],
#       [ 0.89585107,  0.98547797],
#       [ 0.92313706,  1.01572145],
#       [ 0.95043577,  1.04600284],
#       [ 0.97771151,  1.07562624],
#       [ 1.00424776,  1.10520453],
#       [ 1.03109545,  1.13475345],
#       [ 1.05732069,  1.16393063],
#       [ 1.08360187,  1.19263192],
#       [ 1.11048786,  1.22113061],
#       [ 1.13708888,  1.24942238],
#       [ 1.16399727,  1.27720571]])
    
def plot_eph_mes(Psi_Theta_eph,Psi_Theta_mes):
    """
    Cette fonction sert à afficher les deux ensembles de points correspondant aux positions successives du soleil, sous format "azimut - elevation" en radians (elevation nulle -> axe z), d'une part de l'ephemedire et d'autre part des orientations reconstruites.
    """
    plt.figure()
    Psi_Theta_eph=np.array(Psi_Theta_eph)%(2*np.pi)
    Psi_Theta_mes=np.array(Psi_Theta_mes)%(2*np.pi)
    #print(Psi_Theta_mes-Psi_Theta_mes%(2*np.pi))
    #Psi_Theta_mes=Psi_Theta_mes*180/np.pi
    plt.scatter(Psi_Theta_eph[:,0],Psi_Theta_eph[:,1],color="r",label='eph')
    plt.scatter(Psi_Theta_mes[:,0],Psi_Theta_mes[:,1],color="g",label='mes')
    ax3=plt.subplot(111, projection='polar', facecolor='#d5de9c')
            # radar green, solid grid lines
    plt.rc('grid', color='#316931', linewidth=1, linestyle='-')
    plt.rc('xtick', labelsize=15)
    plt.rc('ytick', labelsize=15)
    ax3.set_theta_direction(-1)
    ax3.set_theta_zero_location('N')
    
    
    ax3.plot((Psi_Theta_mes[:,0]),Psi_Theta_mes[:,1], color='g', lw=3, label='Trajectoire mes')#(Psi_Theta_mes[:,0]-np.pi*0.75)
    ax3.plot(Psi_Theta_eph[:,0],Psi_Theta_eph[:,1], color='r', lw=3, label='Trajectoire eph')
    ax3.plot(Psi_Theta_mes[:20,0],Psi_Theta_mes[:20,1], color='y', lw=3, label='Trajectoire mes')
    ax3.plot(Psi_Theta_eph[:20,0],Psi_Theta_eph[:20,1], color='b', lw=3, label='Trajectoire eph')
    ax3.legend()
    
    plt.figure()
    plt.plot(Psi_Theta_eph[:,1],'r',label="eph1")
    plt.plot(Psi_Theta_eph[:,0],'g',label="eph0")
    plt.plot(Psi_Theta_mes[:,1],'r+',label="mes1")
    plt.plot((Psi_Theta_mes[:,0]),'g+',label="mes0")
    
#    plt.plot(Psi_Theta_mes[:,1]%(2*np.pi),label="mes1")
#    plt.plot((Psi_Theta_mes[:,0]+(0))%(2*np.pi),label="mes0")#Psi_Theta_mes[:,0]+(3.9)
    plt.legend()
#plot_eph_mes(Psi_Theta_eph,Psi_Theta_mes)
#plt.figure()
#plt.imshow(somme_image,cmap='rainbow')
#centroides=np.array(centroides)
#plt.scatter(centroides[:,0],centroides[:,1],marker="+")
#plt.scatter(y_0,x_0,marker="+")
#

#    ]# create data to be fitted
#Az=np.array(Az)*np.pi/180.0#+0.0001
#El=np.array(El)*np.pi/180.0#+0.0001


lancer_optim=False
lancer_optim=True#False
afficher_listing=False 

# create a set of Parameters
thres=1.0*50.0
params = Parameters()

params.add('alpha', value=1*(185+57), min=-360, max=360)
params.add('beta', value=0, min=-20, max=20)
params.add('gamma', value=-0, min=-180, max=180)

x_0=1242.46206 #+/- 4.77376421 (0.38%) (init = 1317.528)
#az_0=0.07302955# +/- 0.00403712 (5.53%) (init = 0.03141592)
#el_0=0.00816530 #+/- 0.00841453 (103.05%) (init = 0.0225)
y_0=1009.15336 #+/- 9.15555715 (0.91%) (init = 941.8)

XCoeff,YCoeff=1,1#3.45,3.45

#gamma=-0.02484741 #+/- 0.00471645 (18.98%) (init = -0.0769)
f=548.475391
params.add('x_0', value=1224, min=1150, max=1300)
#params.add('x_0', value=1224, min=1223, max=1225)
params.add('y_0', value=1024,min=1000,max=1150)
#params.add('y_0', value=1024,min=1023,max=1025)
#params.add('az_0', value=0.03141592, min=-np.pi/thres, max=np.pi/thres)#min=-np.pi/thres,max=np.pi/thres)
#params.add('el_0', value=0.0225, min=-np.pi/thres,max=np.pi/thres)

#params.add('gamma', value=-0.0769,min=-np.pi/4,max=np.pi/4)
f_start=548#650#548.475391 #550
params.add('f', value=f_start, min=f_start-100.0, max=f_start+100.0)
#params.add('omega', value=3.0)

# 

centroides=np.array(centroides)

f_hist=[]
alpha_hist=[]
beta_hist=[]
gamma_hist=[]
x_0_hist=[]
y_0_hist=[]
somme_hist=[]
#PT=Psi_Theta_mes
PTe=np.array(Psi_Theta_eph)
PTe=PTe*np.pi/180
Psi_Theta_eph=PTe
def calcul_Psi_Theta_Mes(centroides,x_0,y_0,f,XCoeff,YCoeff):
    theta2=(np.hypot(((centroides[:,1]-y_0)*XCoeff),((centroides[:,0]-x_0)*YCoeff))/f)
    alpha2=np.arctan2((centroides[:,0]-x_0)*YCoeff,(centroides[:,1]-y_0)*XCoeff)
    Psi_Theta_mes2=np.array([alpha2,theta2]).T
    return Psi_Theta_mes2


def myfcn2min(params):#, x, data):

    """define objective function: returns the array to be minimized.
    
    On cherche ici à évaluer, pour un jeu de paramètres donnés (centre optique x_0 et y_0 du capteur 2D, et les trois rotations alpha/beta/gamma de l'ensemble fisheye+capteur par rapport au repère ENU), les distances entre les points mesurés du capteur qui sont transcrits en orientations incidentes du soleil, et les orientations théoriques de l'ephéméride. Renvoie un vecteur de taille 1*n où n est le nombre de mesures incidentes.
    """
    
    alpha=params['alpha']
    beta=params['beta']
    gamma=params['gamma']
    x_0=params['x_0']
#    az_0=params['az_0']
#    el_0=params['el_0']
    y_0 = params['y_0']
    f = params['f']

    #alpha,beta,gamma=90,45,0
#    theta2=(np.hypot(((centroides[:,1]-y_0)*XCoeff),((centroides[:,0]-x_0)*YCoeff))/f)
#    alpha2=np.arctan2((centroides[:,0]-x_0)*YCoeff,(centroides[:,1]-y_0)*XCoeff)
#    
#    Psi_Theta_mes2=np.array([alpha2,theta2]).T
    PT=calcul_Psi_Theta_Mes(centroides,x_0,y_0,f,XCoeff,YCoeff)
    
    r = R.from_euler('ZXY',[alpha+0,beta+0,gamma+0],degrees=True)
    PT_rot_cart=r.apply(np.array(sph2cart2(PT[:,0],PT[:,1])).T).T
    PT_rot=np.array(cart2sph2(PT_rot_cart[0,:],PT_rot_cart[1,:],PT_rot_cart[2,:])).T
    #somme=0
#    az=Az+az_0
#    el=El+el_0
        #print(centroides[i])

    diff=np.array(sph2cart2(PTe[:,0],PTe[:,1])).T-np.array(sph2cart2(PT_rot[:,0],PT_rot[:,1])).T
    somme=diff[:,0]**2+diff[:,1]**2+diff[:,2]**2
    #print("PT : "+str((PT)))
    #print("Somme : "+str((somme)))
    #(x_p-np.array(centroides)[:,0])**2+(y_p-np.array(centroides)[:,1])**2
    #model = amp * np.sin(x*omega + shift) * np.exp(-x*x*decay)
    #print(f+0)
    alpha_hist.append(alpha+0)#result.params.valuesdict()['f'])
    beta_hist.append(beta+0)
    x_0_hist.append(x_0+0)
    y_0_hist.append(y_0+0)
    f_hist.append(f+0)
    gamma_hist.append(gamma+0)
    somme_hist.append(np.sum(somme))
    return somme#model - data


if lancer_optim:
# do fit, here with the default leastsq algorithm
    minner = Minimizer(myfcn2min, params)#, fcn_args=(x))#, data))
    result = minner.minimize(method='least_squares',max_nfev=20000000,xtol=1e-10,ftol=1e-10)

# calculate final result
#final = data + result.residual

# write error report
    report_fit(result)
    alpha=result.params.valuesdict()['alpha']
    beta=result.params.valuesdict()['beta']
    gamma=result.params.valuesdict()['gamma']
    f=result.params.valuesdict()['f']
    x_0=result.params.valuesdict()['x_0']
    y_0=result.params.valuesdict()['y_0']
#theta2=(np.hypot(((centroides[:,1]-y_0)*XCoeff),((centroides[:,0]-x_0)*YCoeff))/f)
#alpha2=np.arctan2((centroides[:,0]-x_0)*YCoeff,(centroides[:,1]-y_0)*XCoeff)
#Psi_Theta_mes2=np.array([alpha2,theta2]).T
#PT=Psi_Theta_mes2
PT=calcul_Psi_Theta_Mes(centroides,x_0,y_0,f,XCoeff,YCoeff)

r = R.from_euler('ZXY',[alpha+0,beta+0,gamma+0],degrees=True)
PT_rot_cart=r.apply(np.array(sph2cart2(PT[:,0],PT[:,1])).T).T
PT_rot=np.array(cart2sph2(PT_rot_cart[0,:],PT_rot_cart[1,:],PT_rot_cart[2,:])).T
plot_eph_mes(Psi_Theta_eph,PT_rot)
#print(PT_rot)
print(r.as_euler('ZXY',degrees=True))



shape_image=(1024*2,1224*2)#(512,612)#(1224/2,1024/2)

coords_image=[]
for i in range(shape_image[0]):
    for j in range(shape_image[1]):
        coords_image.append([j,i])
coords_image=np.array(coords_image)


orientation_pixels=calcul_Psi_Theta_Mes(coords_image,x_0,y_0,f,XCoeff,YCoeff)
#orientation_pixels=calcul_Psi_Theta_Mes(coords_image,x_0,y_0,f,XCoeff,YCoeff)


OP_rot_cart=r.apply(np.array(sph2cart2(orientation_pixels[:,0],orientation_pixels[:,1])).T).T
OP_rot=np.array(cart2sph2(OP_rot_cart[0,:],OP_rot_cart[1,:],OP_rot_cart[2,:])).T

orientation_pixels_ENU=OP_rot.reshape((shape_image[0],shape_image[1],2))



np.save('/media/sf_Echange_MV_Ubuntu/DepouillageINT/rotation.npy',r.as_euler('ZXY',degrees=True))
np.save('/media/sf_Echange_MV_Ubuntu/DepouillageINT/rot_mat.npy',r.as_matrix())

np.save('/media/sf_Echange_MV_Ubuntu/DepouillageINT/orientation_pixels_ENU.npy',orientation_pixels_ENU)

#orientation_pixels[int(x_0),int(y_0)]
#orientation_pixels[:,:,1]
#np.min(orientation_pixels[:,:,1])
#np.where(np.min(orientation_pixels[:,:,1])==(orientation_pixels[:,:,1]))


# try to plot results
try:
#    import matplotlib.pyplot as plt
#    plt.figure()
#    for i in range(int(len(centroides))):
#        if afficher_listing:print(f'{str(i):<3}'+" ",end=" ")
#        #print(str(i)+" ",end=" ")
#        #if
#        plt.scatter(centroides[i][0],centroides[i][1],label="data",color='b')
##        if i<4:
##            plt.scatter(centroides[i][0],centroides[i][1],label="data",color='g')
#        if afficher_listing:print("Données x : "+str(centroides[i][0])+" y : "+str(centroides[i][1]),end=" ")

#        if lancer_optim:
#            x_0=result.params.valuesdict()['x_0']
#            az_0=result.params.valuesdict()['az_0']
#            el_0=result.params.valuesdict()['el_0']
#            y_0=result.params.valuesdict()['y_0']
#            f=result.params.valuesdict()['f']
#            gamma=result.params.valuesdict()['gamma']
#        else :
#            x_0=params['x_0']
#            az_0=params['az_0']
#            el_0=params['el_0']
#            y_0 = params['y_0']
#            f = params['f']
#            gamma=params['gamma']
#        az=Az+az_0
#        el=El+el_0
#    
#        y=y_0+f*np.arccos(np.cos(az[i])*np.cos(el[i]))*np.cos(np.arctan(np.tan(az[i])/np.sin(el[i])))*np.sign(el[i])*(-1)
#        x=x_0+f*np.arccos(np.cos(az[i])*np.cos(el[i]))*np.sin(np.arctan(np.tan(az[i])/np.sin(el[i])))*np.sign(el[i])*(-1)
#        #gamma=-np.pi/32
#        x_p=x*np.cos(gamma)+y*np.sin(gamma)
#        y_p=y*np.cos(gamma)-x*np.sin(gamma)
#        #plt.scatter(x,y,label="fit",color='r')
#        plt.plot([x_p,centroides[i][0]], [y_p,centroides[i][1]],color='k')
#        plt.scatter(x_p,y_p,label="fit",color='y')
##        if i<4:
##            #plt.scatter(x,y,label="fit",color='g')
##            plt.scatter(x_p,y_p,label="fit",color='g')
#        if afficher_listing:print(" Fit x : "+str(x)+" y : "+str(y))
#    #plt.plot(x, data, '+')
#    #plt.plot(x, final)
#    #plt.legend()
#    plt.show()
    plt.figure()
    plt.plot(alpha_hist)
    plt.title("alpha_hist")
    plt.figure()
    plt.plot(beta_hist)
    plt.title("beta_hist")
    plt.figure()
    plt.plot(gamma_hist)
    plt.title("gamma_hist")
    plt.figure()
    plt.plot(x_0_hist)
    plt.title("x_0_hist")
    plt.figure()
    plt.plot(y_0_hist)
    plt.title("y_0_hist")
    plt.figure()
    plt.plot(f_hist)
    plt.title("f_hist")
    
    plt.figure()
    plt.plot(somme_hist)
    plt.title("somme_hist")
    plt.figure()
    plt.title("Points des centroides et centre optique")
    for i in range(centroides.shape[0]):
        plt.scatter(centroides[i,0],centroides[i,1],color="k")#,label="Points Centroides")
    plt.scatter(x_0,y_0,color="r",label="Centre Optique")
    plt.legend()

except ImportError:
    pass
# <end of examples/doc_parameters_basic.py>