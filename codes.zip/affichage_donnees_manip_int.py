#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 10:06:05 2021

Le but de ce code est de traiter les données de la caméra installée sur le toit de l'INT en tenant compte de l'orientation de la caméra précedemment calculée avec le code "calibration_orientation_fisheye_with_sun.py", dans le dossier nommé "path".
@author: leo
"""

import os, sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from tqdm import trange
import skimage.io
import skimage.filters
import cv2
import time
from scipy.spatial.transform import Rotation as R

def cart2sph2(x,y,z):
    """
    Entree : trois tableaux numpy avec les n coordonnées selon l'axe x, y et z de n vecteurs
    Sortie : deux tableaux numpy avec les n coordonnées en azimut et elevation, en radians, avec la convention elevation  à pi/2 si vecteur selon le plan x-y, et nulle selon z.
    """
    azimuth = np.arctan2(y,x)
    elevation = np.pi/2-np.arctan2(z,np.sqrt(x**2 + y**2))
    return azimuth, elevation


def sph2cart2(azimuth,elevation):
    """
    Entree : deux tableaux numpy avec les n coordonnées en azimut et elevation, en radians, avec la convention elevation  à pi/2 si vecteur selon le plan x-y, et nulle selon z.
    Sortie : trois tableaux numpy avec les n coordonnées selon l'axe x, y et z de n vecteurs
    """
    x = np.cos(np.pi/2-elevation) * np.cos(azimuth)
    y = np.cos(np.pi/2-elevation) * np.sin(azimuth)
    z = np.sin(np.pi/2-elevation)
    return x, y, z

def average_angle(angle1,angle2):
    x=np.cos(angle1)+np.cos(angle2)
    y=np.sin(angle1)+np.sin(angle2)
    return np.arctan2(y,x)

def rebin(arr, new_shape): #https://scipython.com/blog/binning-a-2d-array-in-numpy/
    shape = (new_shape[0], arr.shape[0] // new_shape[0],
             new_shape[1], arr.shape[1] // new_shape[1])
    return arr.reshape(shape).mean(-1).mean(1)

def calcul_Psi_Theta_Mes(centroides,x_0,y_0,f,XCoeff,YCoeff):
    theta2=(np.hypot(((centroides[:,1]-y_0)*XCoeff),((centroides[:,0]-x_0)*YCoeff))/f)
    alpha2=np.arctan2((centroides[:,0]-x_0)*YCoeff,(centroides[:,1]-y_0)*XCoeff)
    Psi_Theta_mes2=np.array([alpha2,theta2]).T
    return Psi_Theta_mes2

degrees=np.pi/180
chaine_dossier='ManipeResultats'#/210622'#220522'
runfile('/media/sf_Echange_MV_Ubuntu/DepouillageINT/centroide_images.py')
runfile('/media/sf_Echange_MV_Ubuntu/DepouillageINT/ephemeride.py')
runfile('/media/sf_Echange_MV_Ubuntu/DepouillageINT/rayleight.py')

orientation_ENU=np.load('/media/sf_Echange_MV_Ubuntu/DepouillageINT/orientation_pixels_ENU.npy')
rot_mat=np.load('/media/sf_Echange_MV_Ubuntu/DepouillageINT/rot_mat.npy')
path= "/media/sf_ManipeResultats/"#Le dossier où on lit les images.
dirs = os.listdir( path ) #On liste les fichiers
dirs_files=[]
for file in dirs:
    if file[-4:]=='.npy': #On ne garde que ceux avec l'extension en ".npy". Normalement ils servent à stocker le chemin absolu où les images sont stockées.
        dirs_files.append(file)


i=0
#A=np.array([
#        [1,2,3,4,5,6,7,8],
#        [9,10,11,12,13,14,15,16],
#        [17,18,19,20,21,22,23,24],
#        [25,26,27,28,29,30,31,32],
#        [33,34,35,36,37,38,39,40],
#        [41,42,43,44,45,46,47,48],
#        [49,50,51,52,53,54,55,56],
#        [57,58,59,60,61,62,63,64]])

#definition of which color of the pixel is used
couleur=3 
# 0 : R     1 : G
# 2 : G     3 : B
#definition of which polarizer orientation is used
indice_pol=0
# 0 :  0°   1 : 45°
# 2 : 135°  3 : 90°
#0° -> Vertical



(XSensor,YSensor)=(2448,2048)#259.2,194.4 #Taille du capteurs en pixels*pixels, on prend un pixel sur 10
f=1898 #1200 anc., en um, focale de l'objectif #### /!\ recupere d'apres fit
f = 520.0760167878741
#(x_0,y_0)=(1329.8,952.6) #Centre caméra
#(x_0,y_0)=(YSensor/2,XSensor/2)#Centre caméra
#(x_0,y_0)=(952.6,1329.8)

y_0= 1210.7010985136365 #### /!\ recupere d'apres fit
x_0= 1026.9672870323918

(XCoeff,YCoeff)=(3.45,3.45)#(3673.6/XSensor,2738.4/YSensor)#(3673.6/XSensor,2738.4/YSensor) 
x = np.arange(0,XSensor,1)
y = np.arange(0, YSensor, 1)
xx, yy = np.meshgrid(x, y, sparse=True)

        
        
        
eph=ephemerides()        #Initialisation de la classe servant à calculer les ephemerides


#theta=rebin(theta,(theta.shape[0]//4,theta.shape[1]//4))

i_image=65
dirs_files.sort() #On trie les fichiers par ordre alphabetique. Comme le format est YYYY-MM-DDTHH-mm-ss.npy les fichiers sont tries dans l'ordre chronologique
#centroides=[]
#Psi_Theta_eph=[]
#Psi_Theta_mes=[]

init_somme_image=0

for i_image in trange(len(dirs_files)): #On compte le nombre de fichiers (trange affiche une barre de progression dans le depouillement)
    #if i_image<95:continue
    for chemins_pos in [dirs_files[i_image]]: #pour chaque fichier contenant le nom des chemins contenant les images :
        #\2021-12-14T12-20-12.npy"
        chemins=np.load(path+chemins_pos) #On ouvre le fichier contenant les chemins de l'image
    #    liste_angles=np.load(chemins+"liste_angles"+'.npy').size
        nb_superpixels=4#2 autour de celui au centre soit un carré de 5 superpixels de large soit 20 pixels
        i_eme_image=-1
        angles_az=[]
        
        for chemin in chemins:#chemins_angles_raw_names: 
            i_eme_image+=1
            
            #skip all images but not the one with lower exposure which is the fifth one
            #if (i_eme_image!=4) and (i_eme_image!=6):continue
            #if (i_eme_image!=1) and (i_eme_image!=5):continue

            #if i_eme_image!=5:continue

#                continue
            #if i_image>57:continue #skip images nuit ans ce cas #debug
            #if i_image<55:continue
            #if i_image>200:continue #skip images nuit ans ce cas #debug
            #if i_image<42:continue            

                

            png_raw_name=path+chemin.split('ManipeResultats/')[1] #On reconstitue le chemin de chaque image en ne gardant que la fin du chemin et en l'adaptant au systeme où le dépuillement est fait.
            #plt.imshow(image)
    #        plt.title(png_raw_name)
        #    i_eme_image+=1
        #    couleur='R'    
            liste_expo=np.load(png_raw_name+"liste_expo"+'.npy') #On charge les temps d'exposition notés avec les images
            #print("LISTE EXPO :")
            #print(liste_expo)
            #liste_angles=np.load(png_raw_name+"liste_angles"+'.npy')
            #taille_liste_angles=liste_angles.shape[1]#361
            config_monture=np.load(png_raw_name+"config_monture.npy")
            
            #print("Config Monture : "+str(config_monture)+" Liste Angles : "+str(liste_angles))
        #
        #    somme_image=np.load(png_raw_name+"0"+"R"+'.npy')*0


            #eph.tracePolarSoleil(chainetps=chemin.split('ManipeResultats/')[1],Ax=ax1[0])
            (Psi_sun,Theta_sun)=eph.getAltAzSoleil(chemin.split('ManipeResultats/')[1]) #Calcul de l'ephemeride au moment de la prise de vue
#            print([Psi_sun,90-Theta_sun])
#            
#            if 90-Theta_sun<10:continue

            image=np.load(png_raw_name+str(i_eme_image)+'.npy').astype('int64') #Enfin on charge l'image en question.
            if init_somme_image==0:
                init_somme_image=1
                somme_image=image.copy()
            else:
                somme_image=somme_image+image

#
            theta=orientation_ENU[:,:,1]
            alpha=orientation_ENU[:,:,0]


#            theta=(np.hypot(((centroide_image[1]-x_0)*XCoeff),((centroide_image[0]-y_0)*YCoeff))/f)
#            alpha=np.arctan2((centroide_image[0]-y_0)*YCoeff,(centroide_image[1]-x_0)*XCoeff) #les répartitions angulaires correspondantes aux pixels du capteur 2d. Theta = elevation, alpha=azimut
     
            chainetps=chemin.split('ManipeResultats/')[1]
            chaineheure=chainetps.split("T")[1][0:-1].split("-")
            heure_image=Time(chainetps.split("T")[0]+'T'+chaineheure[0]+":"+chaineheure[1]+":"+chaineheure[2])
    #        print(eph.getAltAzSoleil(heure_image))
    
            #continue
            
            #eph.traceAzELSoleil(chainetps=chemin.split('ManipeResultats/')[1],Ax=ax1[0])
        

            #ici on veut faire "l'angle moyen" vu au centre d'un macropixel. On connait les orientations de chacun des sous-pixels (theta, alpha) mais pour faire l'orientation "centrale" une moyenne bête ne fonctionne pas. Par exemple, la "moyenne" entre deux vecteurs 2D d'angles 45° et 315° serait "en vrai" de 0° mais la moyenne arithmetique des deux angles fait 180°. Ici on a le même problème lors du passage de -pi à pi avec des artefacts numeriques. Pour eviter cela, on repasse en coordonnées cartesiennes et on utilise atan2.
            
            theta_0=theta[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]
            theta_90=theta[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4]
            theta_45=theta[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]
            theta_135=theta[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4]
            theta_mini=average_angle(average_angle(theta_0,theta_90),average_angle(theta_45,theta_135))
        
            alpha_0=alpha[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]
            alpha_90=alpha[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4]
            alpha_45=alpha[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]
            alpha_135=alpha[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4]
            alpha_mini=average_angle(average_angle(alpha_0,alpha_90),average_angle(alpha_45,alpha_135))
        
        
        
            Q=image[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]-image[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4] # I0-I90
            U=image[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]-image[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4] # I45-I135
            I=0.5*(image[((couleur//2)*2+0//2)::4,((couleur%2)*2+0%2)::4]+image[((couleur//2)*2+3//2)::4,((couleur%2)*2+3%2)::4]+image[((couleur//2)*2+1//2)::4,((couleur%2)*2+1%2)::4]+image[((couleur//2)*2+2//2)::4,((couleur%2)*2+2%2)::4]) # (I0 + I90 + I45 + I135)/2
            ksi=(0.5*np.arctan2(U,Q)*180/np.pi)
#            offset_cadrant=U*0
#            offset_cadrant[(U>0)&(Q>0)]=45
#            offset_cadrant[(U<0)&(Q<0)]=135
#            offset_cadrant[(U<0)&(Q>0)]=90
#            
            #DOP=np.sin()
            #ksi=ksi+offset_cadrant
            

            
            
            
            
            
            
            
            ksi[theta_mini>np.pi/2]=0
            
            print("Creation figure ...")
            fig,(ax1,ax2)=plt.subplots(2,3,figsize=(20,12),gridspec_kw={'width_ratios':[1.2,1.2,1.2]})
            #fig.tight_layout()
#            plt.subplots_adjust(left=0.1,right=0.9,top=0.9,bottom=0.1)


            #fig.tight_layout()
            #figManager=plt.get_current_fig_manager()
            #figManager.window.showMaximized()
            plt.suptitle("Image : "+chainetps[:-1]+ " ~ Color channel :  "+str(["R","Gr","Gb","B"][couleur])+" ~ Expo : "+str(liste_expo[i_eme_image])+" µs")
            
            
            print("plot aop image...")
            #plt.figure()
            pcm1=ax2[1].pcolormesh(ksi,cmap='hsv')
            ax2[1].set_title("Measured AOP")#chemin.split('ManipeResultats')[1]+" - AOP - Canal "+str(["R","Gr","Gb","B"][couleur]))
            cbar=fig.colorbar(pcm1,ax=ax2[1])
            cbar.set_ticks([-90,-67.5,-45,-22.5,0,22.5,45,67.5,90])
            cbar.set_label("Angle of Polarization")
            ax2[1].invert_yaxis()
            
            
            
            
            
    
    
            
            
            
            
            print("plot dop image...")
            DOP_dofp=np.hypot(Q,U)/I
    
    
            DOP_dofp[theta_mini>np.pi/2]=0
    
            #plt.figure()
            pcm3=ax2[2].pcolormesh(np.minimum(DOP_dofp,1),cmap='jet')
            ax2[2].set_title("Measured DOP")#chemin.split('ManipeResultats')[1]+" - DOP - Canal "+str(["R","Gr","Gb","B"][couleur]))
            cbardop=fig.colorbar(pcm3,ax=ax2[2])
            #cbardop.vmax=1
            #cbardop.vmin=0
            pcm3.set_clim(0, 1.0)
            cbardop.set_ticks([0,0.2,0.4,0.6,0.8,1])
            cbardop.set_label("Degree of Polarization")
            ax2[2].invert_yaxis()
                #
        
            
            print("plot rgb image...")
            #plt.figure()
            #plt.imshow(Xsi,cmap='hsv')
            a=rebin(image,(image.shape[0]//2,image.shape[1]//2))
            imageRGB=cv2.merge((a[1::2,1::2],a[0::2,1::2],a[0::2,0::2]))
            ###ax2[0].pcolormesh(cv2.cvtColor((imageRGB.astype('float32')/255.0).astype('uint8'), cv2.COLOR_BGR2RGB),color=cv2.cvtColor((imageRGB.astype('float32')/255.0).astype('uint8'), cv2.COLOR_BGR2RGB).reshape(512*612,3))
            ax2[0].imshow(cv2.cvtColor((imageRGB.astype('float32')/255.0).astype('uint8'), cv2.COLOR_BGR2RGB))
            
            d=np.pi/180
            r = R.from_matrix(rot_mat)
            #r = R.from_matrix(np.identity(3))

            
            Sun_rot_cart=r.apply(np.array(sph2cart2(Psi_sun*d,Theta_sun*d)).T).T
            Sun_rot=np.array(cart2sph2(Sun_rot_cart[0],Sun_rot_cart[1],Sun_rot_cart[2])).T
            #Sun_rot[0] -> Psi, (az)
            #Sun_rot[1] -> Theta, zenith = 0 (anti-elev)
            print("Psi_sun : "+str(Psi_sun*degrees)+" Theta_sun : "+str(Theta_sun*degrees))
            print("Sun_rot[0] : "+str(Sun_rot[0])+" Sun_rot[1] : "+str(Sun_rot[1]))
            x_sol,y_sol=np.array([(x_0+f*np.sin(Sun_rot[0])*(Sun_rot[1]))/4]),np.array([(y_0-f*np.cos(Sun_rot[0])*(Sun_rot[1]))/4])
            
            
            
            
            ax2[0].set_title("RGB Image")                 

            
            print("plot ephemeride...")
            eph=ephemerides()
            eph.traceAzELSoleil(chainetps=chemin.split('ManipeResultats/')[1],Ax=ax1[0])
            #eph.tracePolarSoleil(chainetps=chemin.split('ManipeResultats/')[1],Ax=ax1[0])

            (Psi_sun,Theta_sun)=eph.getAltAzSoleil(chemin.split('ManipeResultats/')[1])
            degrees=np.pi/180
            
            #eph.traceAzELSoleil(chainetps=None,Ax=ax2[1])
            #eph=ephemerides()
            #from numba import autojit, prange
            #@autojit
            
       
            
            
            
            
            print("plot simul rayleight...")
    
            simul_rayleight_subplot((Psi_sun),Theta_sun,ax_aop=ax1[1],ax_dop=ax1[2],fig=fig,alpha=alpha,theta=theta,rot_mat=rot_mat)#orientation_pixels_ENU=orientation_ENU)
#            ax1[1].invert_yaxis()
#            ax1[2].invert_yaxis()
            ax2[1].invert_yaxis()
            ax2[2].invert_yaxis()            
            ax2[0].invert_yaxis()
#            ax2[0].scatter(y_sol,x_sol,marker="o",color='r')
#
#            ax1[1].scatter(y_sol,x_sol,marker="o",color='k')
#            ax1[2].scatter(y_sol,x_sol,marker="o",color='k')
#            ax2[1].scatter(y_sol,x_sol,marker="o",color='k')
#            ax2[2].scatter(y_sol,x_sol,marker="o",color='k')
#            
#            ax2[0].scatter(y_0/4,x_0/4,marker="o",color='r')
#            ax2[0].scatter(y_0/4+100,x_0/4,marker="x",color='r')
#            ax2[0].scatter(y_0/4,x_0/4+100,marker="1",color='r')            
#            ax1[1].scatter(y_0/4,x_0/4,marker="o",color='k')
#            ax1[2].scatter(y_0/4,x_0/4,marker="o",color='k')
#            ax2[1].scatter(y_0/4,x_0/4,marker="o",color='k')
#            ax2[2].scatter(y_0/4,x_0/4,marker="o",color='k')            
            
            
            
            plt.subplots_adjust(left=0.05,right=0.95,top=0.90,bottom=0.05,wspace=0.2,hspace=0.2)
            #time.sleep(3)
            ax2[0].axis('scaled')
            ax2[1].axis('scaled')
            ax2[2].axis('scaled')
            ax1[1].axis('scaled')
            ax1[2].axis('scaled')
            print("Sauv AOP/DOP...")
            np.savetxt('/media/sf_Echange_MV_Ubuntu'+'/anim/AOP'+str(i_image)+"_"+str(i_eme_image)+'.txt',ksi,delimiter=',',fmt="%10.6f")
            
            np.savetxt('/media/sf_Echange_MV_Ubuntu'+'/anim/DOP'+str(i_image)+"_"+str(i_eme_image)+'.txt',DOP_dofp,delimiter=',',fmt="%10.6f")
            np.savetxt('/media/sf_Echange_MV_Ubuntu'+'/anim/time'+str(i_image)+"_"+str(i_eme_image)+'.txt',list(map(int,chemin.split('ManipeResultats/')[1][:-1].split('T')[0].split('-')+chemin.split('ManipeResultats/')[1][:-1].split('T')[1].split('-'))),delimiter=',',fmt="%d") # ['YYYY', 'MM', 'DD', 'HH', 'mm', 'ss/']
            print("Sauv fig...")
            plt.savefig('/media/sf_Echange_MV_Ubuntu'+'/anim/'+str(i_image)+"_"+str(i_eme_image)+".png")
            

            plt.close()
            #break
        
        plt.show()
        
#plt.figure()
#Psi_Theta_eph=np.array(Psi_Theta_eph)
#Psi_Theta_eph=Psi_Theta_eph*np.pi/180
#Psi_Theta_mes=np.array(Psi_Theta_mes)
#print(Psi_Theta_mes-Psi_Theta_mes%(2*np.pi))
##Psi_Theta_mes=Psi_Theta_mes*180/np.pi
#plt.scatter(Psi_Theta_eph[:,0],Psi_Theta_eph[:,1],color="r",label='eph')
#plt.scatter(Psi_Theta_mes[:,0],Psi_Theta_mes[:,1],color="g",label='mes')
#ax3=plt.subplot(111, projection='polar', facecolor='#d5de9c')
#        # radar green, solid grid lines
#plt.rc('grid', color='#316931', linewidth=1, linestyle='-')
#plt.rc('xtick', labelsize=15)
#plt.rc('ytick', labelsize=15)
#ax3.set_theta_direction(-1)
#ax3.set_theta_zero_location('N')
#
#        #r = np.arange(0, 30,3)
#        #theta = 2 * np.pi * r
##r=np.array(self.sunaltazs_JourJ.alt)
#        
#        #ax3.set_theta_offset(np.pi/2)
##theta=np.array(self.sunaltazs_JourJ.az.radian)
##thetaPos,self.rPos=self.theta[self.r>0], 90-self.r[self.r>0] 
#
#ax3.plot((Psi_Theta_mes[:,0]-np.pi*0.75),Psi_Theta_mes[:,1], color='g', lw=3, label='Trajectoire mes')
#ax3.plot(Psi_Theta_eph[:,0],Psi_Theta_eph[:,1], color='r', lw=3, label='Trajectoire eph')
#ax3.plot(Psi_Theta_mes[:20,0]-np.pi*0.75,Psi_Theta_mes[:20,1], color='y', lw=3, label='Trajectoire mes')
#ax3.plot(Psi_Theta_eph[:20,0],Psi_Theta_eph[:20,1], color='b', lw=3, label='Trajectoire eph')
#ax3.legend()
#
#plt.figure()
#plt.plot(Psi_Theta_eph[:,1],label="eph1")
#plt.plot(Psi_Theta_eph[:,0],label="eph0")
#plt.plot(Psi_Theta_mes[:,1]%(2*np.pi),label="mes1")
#plt.plot((Psi_Theta_mes[:,0]+(3.9))%(2*np.pi),label="mes0")
#plt.legend()
#
#plt.figure()
#plt.imshow(somme_image,cmap='rainbow')
#centroides=np.array(centroides)
#plt.scatter(centroides[:,0],centroides[:,1],marker="+")
#plt.scatter(y_0,x_0,marker="+")