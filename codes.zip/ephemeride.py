# -*- coding: utf-8 -*-
"""
===================================================================
Determining and plotting the altitude/azimuth of a celestial object
===================================================================

This example demonstrates coordinate transformations and the creation of
visibility curves to assist with observing run planning.

In this example, we make a `~astropy.coordinates.SkyCoord` instance for M33.
The altitude-azimuth coordinates are then found using
`astropy.coordinates.EarthLocation` and `astropy.time.Time` objects.

This example is meant to demonstrate the capabilities of the
`astropy.coordinates` package. For more convenient and/or complex observation
planning, consider the `astroplan <https://astroplan.readthedocs.org/>`_
package.


*By: Erik Tollerud, Kelle Cruz*

*License: BSD*


"""

##############################################################################
# Let's suppose you are planning to visit picturesque Bear Mountain State Park
# in New York, USA. You're bringing your telescope with you (of course), and
# someone told you M33 is a great target to observe there. You happen to know
# you're free at 11:00 pm local time, and you want to know if it will be up.
# Astropy can answer that.
#
# Import numpy and matplotlib. For the latter, use a nicer set of plot
# parameters and set up support for plotting/converting quantities.
import time
import sys
import numpy as np
import matplotlib.pyplot as plt
from astropy.visualization import astropy_mpl_style, quantity_support
plt.style.use(astropy_mpl_style)
quantity_support()


##############################################################################
# Import the packages necessary for finding coordinates and making
# coordinate transformations

import astropy.units as u
from astropy.time import Time
from astropy.coordinates import SkyCoord, EarthLocation, AltAz

##############################################################################
# `astropy.coordinates.SkyCoord.from_name` uses Simbad to resolve object
# names and retrieve coordinates.
#
# Get the coordinates of M33:



##############################################################################
# Use `astropy.coordinates.EarthLocation` to provide the location of Bear
# Mountain and set the time to 11pm EDT on 2012 July 12:
#Luminy : 43.233856735452754, 5.443703565986805
luminy = EarthLocation(lat=43.233856735452754*u.deg, lon=5.443703565986805*u.deg, height=390*u.m)
timone = EarthLocation(lat=43.286990365824785*u.deg, lon=5.403361407820939*u.deg, height=390*u.m)


#time = Time('2021-2-10 12:00:00') - utcoffset
#time = Time.now() - utcoffset



##############################################################################
# Use  `~astropy.coordinates.get_sun` to find the location of the Sun at 1000
# evenly spaced times between noon on July 12 and noon on July 13:

from astropy.coordinates import get_sun

#from astropy.utils.iers import IERS_B_FILE
from astropy.utils.iers import IERS_A_URL_MIRROR







#plt.show()

class ephemerides:
    def __init__(self):
        self.luminy = EarthLocation(lat=43.233856735452754*u.deg, lon=5.443703565986805*u.deg, height=390*u.m)
        self.timone = EarthLocation(lat=43.286990365824785*u.deg, lon=5.403361407820939*u.deg, height=390*u.m)
        self.utcoffset = 2*u.hour  # Eastern Daylight Time - 2h l'été, une l'hiver
        
        self.aujourdhui=str(Time.now().datetime.date())
        self.midday = Time(self.aujourdhui+' 12:00:00') - self.utcoffset
    def getAltAzSoleil(self,chainetps=None):
        if chainetps is None:
            Times_now=Time.now()
        else:
            chaineheure=chainetps.split("T")[1][0:-1].split("-")
            heure_image=Time(chainetps.split("T")[0]+'T'+chaineheure[0]+":"+chaineheure[1]+":"+chaineheure[2])
            Times_now=Time(heure_image,format='isot')
        self.times_now=Times_now-self.utcoffset#Time.now()#-utcoffset#-8*u.hour
        ###print(self.times_now)
        self.frame_now = AltAz(obstime=self.times_now, location=self.timone)
        self.sunaltazs_now = get_sun(self.times_now).transform_to(self.frame_now)
        return (self.sunaltazs_now.az.degree,90-self.sunaltazs_now.alt.degree)
    def tracePolarSoleil(self,chainetps=None,Ax=None):
        if Ax is None:
            Ax=plt.subplot(221) #plt.gca()
        if chainetps is None:
            Times_now=Time.now()
        else:
            chaineheure=chainetps.split("T")[1][0:-1].split("-")
            heure_image=Time(chainetps.split("T")[0]+'T'+chaineheure[0]+":"+chaineheure[1]+":"+chaineheure[2])
            Times_now=Time(heure_image,format='isot')
            #Times-now=datetime.fromiso
        #Times_now=Time.now()
        Times_now.format='isot'
        self.times_now=Times_now-self.utcoffset#Time.now()#-utcoffset#-8*u.hour
        # force square figure and square axes looks better for polar, IMO
        #fig2 = plt.figure(2,figsize=(8, 8))
        #ax3=axs[1]
        #ax3 = fig.add_axes([0.1, 0.1, 0.8, 0.8],
        self.ax3=Ax

        ###print("type(self.times_now)")
        ##print(type(self.times_now))
        self.frame_now = AltAz(obstime=self.times_now, location=self.timone)
        self.sunaltazs_now = get_sun(self.times_now).transform_to(self.frame_now)
       
        self.aujourdhui=str(self.times_now.datetime.date())
        #        self.aujourdhui=str(Time.now().datetime.date())

        self.midday = Time(self.aujourdhui+' 12:00:00') - self.utcoffset
        #midday.value.time=datetime.time(14, 55, 5, 343266)
        
        self.delta_midday = np.linspace(-2, 10, 100)*u.hour
        
        self.diff=(self.times_now-self.midday).value*24
        self.delta_midday = np.linspace(-12, 12, 1000)*u.hour
        self.times_JourJ = self.midday+ self.delta_midday #- self.utcoffset
        self.frame_JourJ = AltAz(obstime=self.times_JourJ, location=self.timone)
        self.sunaltazs_JourJ = get_sun(self.times_JourJ).transform_to(self.frame_JourJ)
        self.ax3=plt.subplot(222,                projection='polar', facecolor='#d5de9c')
        # radar green, solid grid lines
        plt.rc('grid', color='#316931', linewidth=1, linestyle='-')
        plt.rc('xtick', labelsize=15)
        plt.rc('ytick', labelsize=15)
        self.ax3.set_theta_direction(-1)
        self.ax3.set_theta_zero_location('N')
        
        #r = np.arange(0, 30,3)
        #theta = 2 * np.pi * r
        self.r=np.array(self.sunaltazs_JourJ.alt)
        
        #ax3.set_theta_offset(np.pi/2)
        self.theta=np.array(self.sunaltazs_JourJ.az.radian)
        self.thetaPos,self.rPos=self.theta[self.r>0], 90-self.r[self.r>0] 
     
        self.ax3.plot(self.thetaPos,self.rPos, color='#ee8d18', lw=3, label='Trajectoire')
        self.ptSoleil=self.ax3.scatter(self.sunaltazs_now.az.radian,90-self.sunaltazs_now.alt.degree,c = 'tab:orange',marker = 'o',alpha = 0.8,s=200)
        #ax3.plot(theta, r, color='blue', ls='--', lw=3, label='another line')
        self.ax3.legend()
        return self.ax3
    
    def traceAzELSoleil(self,chainetps=None,Ax=None):
        if Ax is None:
            Ax=plt.subplot(221) #plt.gca()
        if chainetps is None:
            Times_now=Time.now()
        else:
            chaineheure=chainetps.split("T")[1][0:-1].split("-")
            heure_image=Time(chainetps.split("T")[0]+'T'+chaineheure[0]+":"+chaineheure[1]+":"+chaineheure[2])
            Times_now=Time(heure_image,format='isot')
            #Times-now=datetime.fromiso
        #Times_now=Time.now()
        Times_now.format='isot'
        self.times_now=Times_now-self.utcoffset#Time.now()#-utcoffset#-8*u.hour
        #self.times_now=Time.now()#-utcoffset#-8*u.hour
#        from datetime import datetime
#        Times_now=Time(datetime.now())
        #self.ax = plt.subplot(221)         
        ###print("self.times_now :")
        ###print(repr(self.times_now))
        ###print("Time.now() :")
        ###print(repr(Time.now()))
        
        self.ax=Ax

        ###print("type(self.times_now)")
        ##print(type(self.times_now))
        self.frame_now = AltAz(obstime=self.times_now, location=self.timone)
        self.sunaltazs_now = get_sun(self.times_now).transform_to(self.frame_now)
       
        self.aujourdhui=str(self.times_now.datetime.date())
        #        self.aujourdhui=str(Time.now().datetime.date())

        self.midday = Time(self.aujourdhui+' 12:00:00') - self.utcoffset
        #midday.value.time=datetime.time(14, 55, 5, 343266)
        
        self.delta_midday = np.linspace(-2, 10, 100)*u.hour
        
        self.diff=(self.times_now-self.midday).value*24
        self.delta_midday = np.linspace(-12, 12, 1000)*u.hour
        self.times_JourJ = self.midday+ self.delta_midday #- self.utcoffset
        self.frame_JourJ = AltAz(obstime=self.times_JourJ, location=self.timone)
        self.sunaltazs_JourJ = get_sun(self.times_JourJ).transform_to(self.frame_JourJ)
        
        
        #############################################################################
        # Do the same with `~astropy.coordinates.get_moon` to find when the moon is
        # up. Be aware that this will need to download a 10MB file from the internet
        # to get a precise location of the moon.
        
        from astropy.coordinates import get_moon
        self.moon_JourJ = get_moon(self.times_JourJ)
        self.moonaltazs_JourJ = self.moon_JourJ.transform_to(self.frame_JourJ)
        
        ##############################################################################
        # Find the alt,az coordinates of M33 at those same times:
        
        #m33altazs_JourJ = m33.transform_to(frame_JourJ)
        
        ##############################################################################
        # Make a beautiful figure illustrating nighttime and the altitudes of M33 and
        # the Sun over that time:
        
        
        
    
        #ax1 = fig.add_axes([0, 0, 1, 1])
        #ax2 = fig.add_axes()
        
        self.ax.plot(self.delta_midday, self.sunaltazs_JourJ.alt, color='r', label='Elevation',zorder=2)
        self.ax2=self.ax.twinx()
        self.ax2.plot(self.delta_midday, self.sunaltazs_JourJ.az, color='g', label='Azimut',zorder=1)
        #plt.plot(delta_midday, moonaltazs_JourJ.alt, color=[0.75]*3, ls='--', label='Moon')
        #plt.scatter(delta_midnight, m33altazs_July12_to_13.alt,
        #            c=m33altazs_July12_to_13.az, label='M33', lw=0, s=8,
        #            cmap='viridis')
        self.ax.fill_between(self.delta_midday, 0*u.deg, 90*u.deg,
                         self.sunaltazs_JourJ.alt < -0*u.deg, color='0.5', zorder=0)
        self.ax.fill_between(self.delta_midday, 0*u.deg, 90*u.deg,
                         self.sunaltazs_JourJ.alt < -18*u.deg, color='k', zorder=0)
        #plt.colorbar().set_label('Azimuth [deg]')
        
        self.ax.set(title="Sun Position - La Timone (Marseille, France) - "+str(self.midday).split()[0])
        self.ax.set_xlim(-12*u.hour, 12*u.hour)
        self.ax.set_xticks((np.arange(13)*2-12)*u.hour)#,np.arange(13)*2%12)
        self.ax.set_xticklabels(np.arange(13)*2)
        self.ax.set_yticks((np.arange(0,80,10))*u.deg)
        self.ax2.set_yticks((np.arange(0,360,45))*u.deg)
        #plt.xtickslabels()
        self.ax.set_ylim(0*u.deg, 80*u.deg)
        self.ax2.set_ylim(0*u.deg, 360*u.deg)
        self.ax.set_xlabel('Heure de la journée')
        self.ax.set_ylabel('')
        self.ax2.set_ylabel('')
        
        self.legende1=self.ax.legend(loc="upper left")
        self.legende2=self.ax2.legend(loc="upper right").set_zorder(13)
        self.legende1.remove()
        self.ax2.add_artist(self.legende1)
        #legend1.set_zorder(14)
        
        self.props = dict(boxstyle='round', facecolor='wheat', alpha=0.9)
        self.texte1=self.ax.text(0.05,0.87, str(round(self.sunaltazs_now.alt.degree,2))+" °" , transform=self.ax.transAxes, fontsize=14,
                horizontalalignment='left',
                verticalalignment='top', bbox=self.props,zorder=11)
        self.texte2=self.ax2.text(0.95,0.87, str(round(self.sunaltazs_now.az.degree,2))+" °" , transform=self.ax.transAxes, fontsize=14,
                horizontalalignment='right',
                verticalalignment='top', bbox=self.props,zorder=10)
        self.texte1.remove()
        self.ax2.add_artist(self.texte1)
        self.texte_heure=str(self.times_now.value)#.time())
        self.texteh=self.ax2.text(0.5,0.9, self.texte_heure , transform=self.ax.transAxes, fontsize=14,
                horizontalalignment='center',
                verticalalignment='top', bbox=self.props,zorder=10)
        self.pltSoleilAz=self.ax2.scatter(self.diff,self.sunaltazs_now.az.degree,c = 'tab:orange',marker = 'o',alpha = 0.8,s=200)
        self.ptSoleilAlt=self.ax.scatter(self.diff,self.sunaltazs_now.alt.degree,c = 'tab:orange',marker = 'o',alpha = 0.8,s=200)
        #return (ax,ax2,midday,texte1,texte2,texteh,ptSoleilAlt,pltSoleilAz)




    def dessin_soleil(self):#(ax,ax2,midday,texte1,texte2,texteh,pltSoleilAlt,pltSoleilAz)):
        #print(*params)
        self.times_now=Time.now()#-utcoffset#-8*u.hour
        print(self.times_now)
        self.frame_now = AltAz(obstime=self.times_now, location=self.timone)
        self.sunaltazs_now = get_sun(self.times_now).transform_to(self.frame_now)
        self.diff=(self.times_now-self.midday).value*24
        self.texte1.set_text(str(round(self.sunaltazs_now.alt.degree,2))+" °" )
        self.texte2.set_text(str(round(self.sunaltazs_now.az.degree,2))+" °" )
        self.texte_heure=str(self.times_now.value.time())
        self.texteh.set_text(self.texte_heure)
        self.pltSoleilAz.set_offsets((self.diff,self.sunaltazs_now.az.degree))
        self.ptSoleilAlt.set_offsets((self.diff,self.sunaltazs_now.alt.degree))    
        plt.show()
    
#if __name__=="__main__":  
##    fig=plt.figure(1)
##    plt.tight_layout()
#    eph=ephemerides()
##    plt.ion()
#    params=eph.traceAzELSoleil()


#while(plt.fignum_exists(1)):
#    eph.dessin_soleil()
#    plt.pause(0.001)
#    plt.show()